import loginCypress from "../e2e/loginApp.cy"

describe('admin page', ()=>{
    it()
})