// class loginPage{

//     elements={
//         userName: ()=> cy.get('[name="username"]'),
//         password: ()=> cy.get('[name="password"]'),
//         loginButton: ()=> cy.get('button[type="submit"]')
//     }

//     login(){
//         this.elements.userName().type("Admin");
//         this.elements.password().type("admin123");
//         this.elements.loginButton().click();
//     }
// }

// module.exports=new loginPage();

import loginLocators from "../webLocators/login.json"

export class loginClass
{
    username(email)
    {
        cy.get(loginLocators.login.userName).type(email)
        cy.get(loginLocators.login.userName).should("be.visible")
    }

    password(password)
    {
        cy.get(loginLocators.login.password).type(password)
        cy.get(loginLocators.login.password).should("be.visible")
    }

    submit()
    {
        cy.get(loginLocators.login.loginBtn).should("be.visible")
        cy.get(loginLocators.login.loginBtn).click()
        
    }

    title()
    {
        cy.title().should('eq', 'OrangeHRM')
    }


}